export const metadata = {
  title: "Parth Dhanani AutoEditor — Cinematic editing, made simple",
  description: "A minimalist local video editor for images, video, voiceover, captions and motion.",
  icons: { icon: "/logo.svg" },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
